import './App.css';
import React, { Fragment } from 'react';
import Search_Content from './Components/Search';
// Components
function App() {
  return (
    <Fragment>
      <Search_Content></Search_Content>
    </Fragment>
  );
}

export default App;
